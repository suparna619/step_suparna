exports.questions = [
	{q:'1+1=',a:'2'},
	{q:'4/2=',a:'2'}
];